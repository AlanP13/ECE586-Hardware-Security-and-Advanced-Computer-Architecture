import os

def generate_input():
    f = open("input.txt", "w")
    count = 0
    for i in range(1000):
        # B1(0), T(1)
        f.write("01\n")
        count += 1
        for j in range(4):
            # B2(1), T(1)
            f.write("11\n")
            count += 1
        # B2(1), NT(0)
        f.write("10\n")
        count += 1
    # B1(0), NT(0)
    f.write("00")
    count += 1
    f.close()
    print(count)

def format_output():
    out = open("outcome.csv", "w")
    out.write("Branch,Actual Branch Outcome,Prediction,Correct? [Y/N]\n")

    count = 0

    with open("output.txt", "r") as f:
        lines = f.readlines()
        for line in lines:
            if line[0] == 'x':
                continue

            branch = "B1"
            outcome = "NT"
            prediction = "NT"
            hit = "N"

            if line[0] == '1':
                branch = "B2"
            if line[1] == '1':
                outcome = "T"
            if line[2] == '1':
                prediction = "T"
            if line[3] == '1':
                hit = "Y"
                count += 1

            out.write(branch+","+outcome+","+prediction+","+hit+"\n")

        print("Number of hits:", count)
        print("Number of misses:", (len(lines)-1-count))
        print("Hit rate:", str((count/(len(lines)-1))*100)+"%")

# Main execution
if __name__ == "__main__":
    generate_input()
    format_output()
