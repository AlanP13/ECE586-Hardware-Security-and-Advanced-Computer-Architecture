int c;
int main () {
  int i, j;
  for (i=0; i<1000; i++) {
    for (j=0; j<4; j++) {
      c++;
    }
  }
  return c;
}