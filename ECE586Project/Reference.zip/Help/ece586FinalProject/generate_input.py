f = open("input.txt", "w")

count = 0
for i in range(1000):
    # B1(0), T(1)
    f.write("01\n")
    count += 1
    for j in range(4):
        # B2(1), T(1)
        f.write("11\n")
        count += 1
    # B2(1), NT(0)
    f.write("10\n")
    count += 1
# B1(0), NT(0)
f.write("00")
count += 1

f.close()
print(count)
